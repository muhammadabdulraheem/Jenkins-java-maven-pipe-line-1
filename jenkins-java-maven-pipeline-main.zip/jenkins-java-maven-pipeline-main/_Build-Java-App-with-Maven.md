// Build Java App with Maven

Reference: https://www.jenkins.io/doc/tutorials/build-a-java-app-with-maven/

git clone https://github.com/atulkamble/simple-java-maven-app.git
cd simple-java-maven-app



